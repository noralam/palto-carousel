=== Palto Carousel ===
Contributors: nalam
Donate link: http://digitalkroy.com/noor-alam
Tags: carousel,slider,image,hover,animation,autoplay,responsive
Requires at least: 3.9
Tested up to: 4.5
Stable tag: Trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Palto carousel is nice wordpress carousel plugin. You can use this plugin any wordpress site for create carousel.

== Description ==
<h4>Palto Carousel is one of the most user friendly wordpress plugin.</h4>
<p>You can create unlimited carousel with lots of options by Palto Carousel.You can set new options for every carousel.You can set new options for every carousel.Palto Carousel also support image lightbox with effects.Palto Carousel has lots of icons for arrow button.Palto Carousel supports arrow button, dots, variable width, center mode, CSS3 Animation Easing, hover animation, draggable, fade and much more.</p>
<h4>Most powerful features: </h4>
    <ul>
	  <li><strong>Fully responsive. Scales with its container.</strong></li>
		<li><strong>Lots of icon for arrow button.</strong></li>
		<li><strong>Border support.</strong></li>
		<li><strong>Four different image size supports. </strong></li>
		<li><strong>User-friendly Editor.</strong></li>
		<li><strong>CSS3 Animation support.</strong></li>
		<li><strong>Images lightbox support.</strong></li>
		<li><strong>7 lightbox effect.</strong></li>
		<li><strong>15 hover animation.</strong></li>
		<li><strong>Carousel center mode.</strong></li>
		<li><strong>Carousel variable width.</strong></li>
		<li><strong>RTL support.</strong></li>
		<li><strong>Mobile first function.</strong></li>
		<li><strong>Different dots position.</strong></li>
		<li><strong>Different arrow position.</strong></li>
	</ul>


#### Translations

* English

== Installation ==

<h2>This section describes how to install the plugin and get it working.</h2>

e.g.

<h4>First things first, thank you for choosing our Palto Carousel lite plugin!</h4>
<h4>You can install the plugin one of two ways:</h4>
<h4>Install using FTP</h4>
<ol>
	<li>Unzip the Palto Carousel.zip file locally to your machine</li>
	<li>Connect to your FTP area using your preferred FTP package</li>
	<li>Upload the Palto Carousel folder that you extracted from the zip file to the plugin folder of your WordPress installation (wp-content -> plugin)</li>
	<li>Go to plugin and activate Palto Carousel.</li>
</ol>
<h4>Install by WordPress (recommended)</h4>
<ol>
	<li>Login to your WordPress admin area.</li>
	<li>Navigate to plugin and click the Add New button at the top</li>
	<li>Click the Upload plugin button at the top</li>
	<li>Click the Choose File button and locate the Palto Carousel.zip </li>
	<li>File on your machine and click the Install Now button </li>
	<li>On the basis the plugin installs correctly, click the Activate link.</li>
</ol>

== Frequently Asked Questions  ==

= Can I crate image carousel by Palto Carousel  =

 yes, you can create image carousel.

= How many carousel can I create =

 You can create unlimited carousel by this plugin with lots of options.


== Screenshots ==




== Changelog ==

= 1.0.0 =
Released version

compatible with wordpress 4.5

